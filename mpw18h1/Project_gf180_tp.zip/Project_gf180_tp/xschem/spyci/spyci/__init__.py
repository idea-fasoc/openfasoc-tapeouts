"""Top-level package for Spice Raw Parser."""

__author__ = """Gonçalo Magno"""
__email__ = 'goncalo@gmagno.dev'
__version__ = '1.0.2'
