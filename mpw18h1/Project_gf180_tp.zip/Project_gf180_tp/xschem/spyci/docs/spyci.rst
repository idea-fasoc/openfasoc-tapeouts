spyci package
=============

Submodules
----------

spyci.cli module
----------------

.. automodule:: spyci.cli
    :members:
    :undoc-members:
    :show-inheritance:

spyci.spyci module
------------------

.. automodule:: spyci.spyci
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: spyci
    :members:
    :undoc-members:
    :show-inheritance:
