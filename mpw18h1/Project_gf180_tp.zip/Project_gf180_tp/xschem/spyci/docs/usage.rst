=====
Usage
=====

To use Spyci in a project::

    import spyci
