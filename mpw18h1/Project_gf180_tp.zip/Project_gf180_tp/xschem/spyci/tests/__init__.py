"""Unit test package for spyci."""
