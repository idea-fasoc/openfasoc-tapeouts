#!/usr/bin/env python
"""Tests for `spyci` package."""

# import pytest

# from spyci import spyci


def test_dummy():
    print("Dummy test")
